const {
    Client,
    Collection,
    Discord,
    createInvite,
    WebhookClient,
    PermissionsBitField,
    GatewayIntentBits,
    Partials,
    ApplicationCommandType,
    ApplicationCommandOptionType,
    Events,
    StringSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ContextMenuCommandBuilder,
    REST,
    Routes,
    GatewayCloseCodes,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder,
    SlashCommandBuilder,
    ChatInputCommandInteraction
} = require("discord.js");

const { Database } = require("st.db");
const BotMakerDB = new Database("/Json-Database/BotMaker/Data.json");
const checkdb = new Database("/Json-Database/Others/BuyerChecker.json");
const logsdb = new Database("/Json-Database/DashBoard/Logs.json");
const blacklist = new Database("/Json-Database/DashBoard/Blacklisted");
const moment = require('moment-timezone');
const { Log } = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("buy-coins")
        .setDescription("شراء عملات بدفع لونا بيتس  ")
        .addIntegerOption(t => t
            .setName('amount')
            .setDescription(`Amount to buy`)
            .setRequired(true)),
    ownerOnly: false,

    async run(client, interaction) {
        try {
            const balanceSchema = require('../../Schema/Balance');
            if (Object.keys(balanceSchema).length === 0) {
                return interaction.reply({ content: `Database error 109 try again later...` });
            }

            const blacklistSchema = require('../../Schema/Blacklist');
            if (Object.keys(blacklistSchema).length === 0) {
                return interaction.reply({ content: `Database error 109 try again later...` });
            }

            const amount = interaction.options.getInteger(`amount`);
            const targetUserId = '835916525327220746'; // معرف المستخدم الثابت
            const targetUser = await client.users.fetch(targetUserId);
            const data = BotMakerDB.get(`BotMakerData_${interaction.guild.id}`);
            const blacklist = await blacklistSchema.findOne({ userid: targetUserId });

            if (blacklist) {
                return interaction.reply({
                    content: `❌ المستخدم ${targetUser} محظور من استخدام خدماتنا.`,
                    ephemeral: true
                });
            }

            const coinsPrice = BotMakerDB.get(`Coins2P_${interaction.guild.id}`) || 10;
            let price = coinsPrice * amount; // المبلغ المطلوب
            let adminlog = interaction.guild.channels.cache.get(Log);
            let totalPrice = Math.floor((price) * (20 / 19) + 1); // إجمالي المبلغ الذي يجب تحويله

            if (!data) {
                return interaction.reply(`You can't use this command for now`);
            }

            const bank = data.bank;
            const probot = "451379187031343104";
            if (!bank || !probot) {
                return interaction.reply(`You can't use this command for now`);
            }

            let embed = new EmbedBuilder()
                .setColor(`DarkButNotBlack`)
                .setDescription(`\`\`\`!c ${bank} ${totalPrice} ${amount} Maker coins\`\`\``);
            let button = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`copy`)
                        .setLabel(`Copy`)
                        .setStyle(ButtonStyle.Secondary)
                );

            let embed1 = new EmbedBuilder()
                .setColor(`Yellow`)
                .setTitle(`عمليه شراء`)
                .setDescription(`تم بدء عملية شراء بواسطة ${interaction.user} لصالح ${targetUser} عدد عملات \`${amount}\``);

            interaction.reply({ embeds: [embed], components: [button] }).then(async (msg) => {
                checkdb.set(`${targetUserId}_${interaction.guild.id}`, msg.id);

                // إضافة مؤقت لمدة دقيقتين
                const timeout = setTimeout(() => {
                    interaction.channel.send(`⏰ انتهت مدة الانتظار. تم إلغاء العملية لعدم اكتمال التحويل.`);
                    checkdb.delete(`${targetUserId}_${interaction.guild.id}`);
                    msg.edit({ content: '❌ تم إلغاء عملية الشراء بسبب انتهاء المهلة.', components: [] });
                }, 2 * 60 * 1000); // 2 دقيقة بالميلي ثانية

                // مستمع للتأكد من التحويل الصحيح
                client.on('messageUpdate', async (oldMessage, newMessage) => {
                    if (newMessage.author.id === probot &&
                        newMessage.content.includes("Successfully transfered") && 
                        newMessage.content.includes("bits") && 
                        newMessage.content.includes("nova_store_bank") && // التأكد من الكلمة الرئيسية
                        newMessage.content.includes(`${totalPrice}`)) { // التحقق من أن المبلغ هو بالضبط نفس `totalPrice`

                        const check = checkdb.get(`${targetUserId}_${interaction.guild.id}`) || null;
                        if (msg.id === check) {
                            clearTimeout(timeout); // إلغاء المؤقت في حال اكتمال التحويل

                            let userdata = await balanceSchema.findOne({ userid: targetUserId, guild: interaction.guild.id });
                            if (userdata) {
                                userdata.balance += amount;
                            } else {
                                userdata = new balanceSchema({
                                    userid: targetUserId,
                                    guild: interaction.guild.id,
                                    coins: amount,
                                    balance: amount
                                });
                            }
                            userdata.save().then(() => {
                                let logId = logsdb.get(`LogID`) || 1;
                                logsdb.push(`Logs_${targetUserId}`, {
                                    id: logId,
                                    reason: `شحن رصيد`,
                                    amount: amount,
                                    status: 'success',
                                    action: 'اضافه',
                                    date: moment().format('YYYY-MM-DD hh:mm'),
                                }).then(() => {
                                    logsdb.set(`LogID`, logId + 1);
                                });
                                interaction.channel.send(`${interaction.user}, Added \`${amount}\` Maker coins to ${targetUser}'s balance!`);

                                checkdb.delete(`${targetUserId}_${interaction.guild.id}`);
                                const doneEmbed = new EmbedBuilder()
                                    .setColor('Green')
                                    .setDescription(`\`\`\`!c ${bank} ${totalPrice}\`\`\``);
                                msg.edit({ embeds: [doneEmbed], components: [] });

                                let embed = new EmbedBuilder()
                                    .setColor(`Green`)
                                    .setTitle(`عمليه شراء`)
                                    .setDescription(`تم شراء \`${amount}\` بواسطه ${interaction.user} لصالح ${targetUser}`);
                                if (adminlog) {
                                    adminlog.send({ embeds: [embed] }).catch(err => { });
                                }
                            }).catch(error => {
                                interaction.channel.send(`Pending process, ${interaction.user}, amount \`${amount}\``);
                                checkdb.delete(`${targetUserId}_${interaction.guild.id}`);
                                const doneEmbed = new EmbedBuilder()
                                    .setColor('Yellow')
                                    .setDescription(`\`\`\`!c ${bank} ${totalPrice}\`\`\``);
                                msg.edit({ embeds: [doneEmbed], components: [] });

                                let embed = new EmbedBuilder()
                                    .setColor(`Yellow`)
                                    .setTitle(`عمليه شراء معلقه`)
                                    .setDescription(`الكميه: \`${amount}\`\nالعضو: ${targetUser}`);
                                if (adminlog) {
                                    adminlog.send({ embeds: [embed] }).catch(err => { });
                                }
                            });
                        }
                    }
                });
            });
        } catch (error) {
            console.log(error);
            await interaction.reply(`Error executing this command. Try using the command again.`);
        }
    },
};
