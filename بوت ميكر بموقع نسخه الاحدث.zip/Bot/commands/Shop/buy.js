const { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    PermissionFlagsBits 
} = require("discord.js");
const { Database } = require("st.db");

const db = new Database("./Bot/Json-Database/Settings/shopDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('buy')
        .setDescription('شراء منتج معين.')
        .addStringOption(option => 
            option.setName('product')
                .setDescription('اسم المنتج الذي تريد شراءه.')
                .setRequired(true)
        )
        .addIntegerOption(option => 
            option.setName('quantity')
                .setDescription('الكمية المراد شراؤها.')
                .setRequired(true)
        ),
    type: "Shop",
    

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction) {
        try {
            const productName = interaction.options.getString('product');
            const quantity = interaction.options.getInteger('quantity');
            const guildId = interaction.guild.id;

            // جلب المنتجات من قاعدة البيانات
            let products = db.get(`Products_${guildId}`) || [];
            const product = products.find(p => p.name === productName);

            // التحقق من وجود المنتج
            if (!product) {
                return interaction.reply({
                    content: `❌ المنتج **${productName}** غير موجود!`,
                    ephemeral: true,
                });
            }

            // التحقق من توفر الكمية
            if (product.stock.length < quantity) {
                return interaction.reply({
                    content: `❌ الكمية المطلوبة غير متوفرة! المتوفر حاليًا: **${product.stock.length}**.`,
                    ephemeral: true,
                });
            }

            // حساب السعر الإجمالي
            const pricePerItem = product.price;
            const totalPrice = pricePerItem * quantity;
            const finalPrice = Math.floor(totalPrice * (20 / 19) + 1);

            // جلب إعدادات الدفع من كائن واحد
            const paymentData = db.get('paymentData') || {};
            const recipient = paymentData[`recipient_${guildId}`];
            const probotId = paymentData[`probot_${guildId}`];

            // التحقق من اكتمال البيانات
            if (!recipient || !probotId) {
                return interaction.reply({
                    content: `❌ إعدادات الدفع غير مكتملة! الرجاء استخدام \`/setup\` لإعداد الدفع.`,
                    ephemeral: true,
                });
            }

            // إرسال Embed لطلب التحويل
            const paymentEmbed = new EmbedBuilder()
                .setDescription(`🔄 قم بتحويل \`${finalPrice}\` إلى <@${recipient}> لإتمام عملية الشراء.\n\`\`\`#credit ${recipient} ${finalPrice}\`\`\`\nلديك 3 دقائق لإتمام العملية.`)
                .setTimestamp(Date.now() + 60 * 3 * 1000)
                .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

            const transferMessage = await interaction.reply({ embeds: [paymentEmbed] });

            // إعداد المُجمِّع للتحقق من التحويل
            const collectorFilter = m =>
                m.content.includes(totalPrice) &&
                (m.content.includes(recipient) || m.content.includes(`<@${recipient}>`)) &&
                m.author.id === probotId;

            const collector = interaction.channel.createMessageCollector({ filter: collectorFilter, max: 1, time: 1000 * 60 * 3 });

            collector.on('collect', async () => {
                // استخراج العناصر من الستوك بعد الدفع
                const purchasedItems = product.stock.splice(0, quantity);
                db.set(`Products_${guildId}`, products); // تحديث قاعدة البيانات

                // إنشاء Embed لتأكيد الشراء
                const successEmbed = new EmbedBuilder()
                    .setTitle('✅ تم الشراء بنجاح!')
                    .setDescription('ستصلك المنتجات في الخاص.')
                    .setTimestamp();

                await interaction.followUp({ content: `${interaction.user}`, embeds: [successEmbed] });

                // إرسال المنتجات في الخاص
                const goodsEmbed = new EmbedBuilder()
                    .setTitle('🛍️ منتجاتك')
                    .setDescription('هذه هي المنتجات التي قمت بشرائها:')
                    .setTimestamp();

                purchasedItems.forEach(item => {
                    goodsEmbed.addFields({ name: 'منتج:', value: `\`\`\`${item}\`\`\``, inline: false });
                });

                await interaction.user.send({ embeds: [goodsEmbed] });
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    transferMessage.delete().catch(() => {});
                    interaction.followUp({
                        content: '❌ انتهى الوقت ولم يتم استلام التحويل.',
                        ephemeral: true,
                    });
                }
            });
        } catch (error) {
            console.error(error);
            interaction.reply({
                content: '❌ حدث خطأ أثناء عملية الشراء!',
                ephemeral: true,
            });
        }
    },
};
