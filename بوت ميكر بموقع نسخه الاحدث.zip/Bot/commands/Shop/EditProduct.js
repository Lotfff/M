const {
    Client,
    EmbedBuilder,
    SlashCommandBuilder,
    PermissionFlagsBits,
    ChatInputCommandInteraction,
} = require("discord.js");
const { Database } = require("st.db");

const db = new Database("./Bot/Json-Database/Settings/shopDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('manage-products')
        .setDescription('تعديل أو حذف منتج.')
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('حذف منتج.')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('اسم المنتج المراد حذفه.')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('edit')
                .setDescription('تعديل منتج.')
                .addStringOption(option =>
                    option.setName('old_name')
                        .setDescription('اسم المنتج القديم.')
                        .setRequired(true)
                )
                .addStringOption(option =>
                    option.setName('new_name')
                        .setDescription('اسم المنتج الجديد.')
                        .setRequired(true)
                )
                .addNumberOption(option =>
                    option.setName('price')
                        .setDescription('السعر الجديد للمنتج.')
                        .setRequired(true)
                )
        ),
    type: "Shop",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction, language, reply, replyEmbeds) {
        try {
            const subcommand = interaction.options.getSubcommand();
            const guildId = interaction.guild.id;

            // جلب قائمة المنتجات من قاعدة البيانات
            let products = db.get(`Products_${guildId}`) || [];

            if (subcommand === 'delete') {
                const productName = interaction.options.getString('name');
                const productIndex = products.findIndex(p => p.name === productName);

                if (productIndex === -1) {
                    return interaction.reply({
                        content: `❌ المنتج **${productName}** غير موجود!`,
                        ephemeral: true,
                    });
                }

                products.splice(productIndex, 1);
                db.set(`Products_${guildId}`, products);

                interaction.reply({
                    content: `✅ تم حذف المنتج **${productName}** بنجاح.`,
                    allowedMentions: { repliedUser: false },
                });

            } else if (subcommand === 'edit') {
                const oldName = interaction.options.getString('old_name');
                const newName = interaction.options.getString('new_name');
                const newPrice = interaction.options.getNumber('price');

                const product = products.find(p => p.name === oldName);

                if (!product) {
                    return interaction.reply({
                        content: `❌ المنتج **${oldName}** غير موجود!`,
                        ephemeral: true,
                    });
                }

                product.name = newName;
                product.price = newPrice;
                db.set(`Products_${guildId}`, products);

                interaction.reply({
                    content: `✅ تم تعديل المنتج **${oldName}** إلى **${newName}** بسعر **${newPrice}**.`,
                    allowedMentions: { repliedUser: false },
                });
            }

        } catch (error) {
            console.error(error);
            interaction.reply({
                embeds: [replyEmbeds.errorEmbed],
                ephemeral: true,
                allowedMentions: { repliedUser: false },
            });
        }
    },
};
