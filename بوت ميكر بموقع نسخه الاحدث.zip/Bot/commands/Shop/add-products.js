const {
    Client,
    EmbedBuilder,
    SlashCommandBuilder,
    PermissionFlagsBits,
    ChatInputCommandInteraction,
} = require("discord.js");
const { Database } = require("st.db");

const db = new Database("./Bot/Json-Database/Settings/shopDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-product')
        .setDescription('أضف منتجًا جديدًا مع السعر.')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('اسم المنتج.')
                .setRequired(true)
        )
        .addNumberOption(option =>
            option.setName('price')
                .setDescription('سعر المنتج.')
                .setRequired(true)
        ),
    type: "Shop",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction, language, reply, replyEmbeds) {
        try {
            const productName = interaction.options.getString('name');
            const productPrice = interaction.options.getNumber('price');
            const guildId = interaction.guild.id;

            // التحقق إذا كان المنتج مضاف مسبقًا
            let products = db.get(`Products_${guildId}`) || [];
            if (products.some(product => product.name === productName)) {
                return interaction.reply({
                    content: `❌ المنتج **${productName}** مضاف بالفعل!`,
                    ephemeral: true,
                });
            }

            // إضافة المنتج إلى القائمة وحفظها
            products.push({ name: productName, price: productPrice });
            db.set(`Products_${guildId}`, products);

            // تأكيد الإضافة
            interaction.reply({
                content: `✅ تم إضافة المنتج **${productName}** بسعر **${productPrice}**.`,
                allowedMentions: { repliedUser: false },
            });

        } catch (error) {
            console.error(error);
            interaction.reply({
                embeds: [replyEmbeds.errorEmbed],
                ephemeral: true,
                allowedMentions: { repliedUser: false },
            });
        }
    },
};
