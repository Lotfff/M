const {
    Client,
    SlashCommandBuilder,
    PermissionFlagsBits,
    ChatInputCommandInteraction,
} = require("discord.js");
const { Database } = require("st.db");

const db = new Database("./Bot/Json-Database/Settings/shopDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('إعداد بيانات الدفع (ProBot ID و Recipient ID).')
        .addStringOption(option =>
            option.setName('probot_id')
                .setDescription('أدخل ID الخاص بـ ProBot.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('recipient_id')
                .setDescription('أدخل ID المستلم.')
                .setRequired(true)
        ),
    type: "Shop",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction) {
        try {
            const probotId = interaction.options.getString('probot_id');
            const recipientId = interaction.options.getString('recipient_id');
            const guildId = interaction.guild.id;

            // جلب جميع البيانات الحالية أو إنشاء كائن جديد
            let allData = db.get('paymentData') || {};

            // تحديث البيانات الخاصة بالسيرفر
            allData[`probot_${guildId}`] = probotId;
            allData[`recipient_${guildId}`] = recipientId;

            // حفظ الكائن الكامل في قاعدة البيانات
            db.set('paymentData', allData);

            // تأكيد الإعداد
            interaction.reply({
                content: `✅ تم إعداد ProBot ID: **${probotId}** و Recipient ID: **${recipientId}** بنجاح.`,
                allowedMentions: { repliedUser: false },
            });

        } catch (error) {
            console.error(error);
            interaction.reply({
                content: '❌ حدث خطأ أثناء الإعداد!',
                ephemeral: true,
                allowedMentions: { repliedUser: false },
            });
        }
    },
};
