const { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    PermissionFlagsBits 
} = require("discord.js");
const { Database } = require("st.db");

const db = new Database("./Bot/Json-Database/Settings/shopDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('give')
        .setDescription('إعطاء منتجات لمستخدم معين.')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('المستخدم الذي تريد إعطاؤه المنتج.')
                .setRequired(true)
        )
        .addStringOption(option => 
            option.setName('product')
                .setDescription('اسم المنتج.')
                .setRequired(true)
        )
        .addIntegerOption(option => 
            option.setName('quantity')
                .setDescription('الكمية المراد إعطاؤها.')
                .setRequired(true)
        ),
    type: "Shop",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction) {
        try {
            const targetUser = interaction.options.getUser('user');
            const productName = interaction.options.getString('product');
            const quantity = interaction.options.getInteger('quantity');
            const guildId = interaction.guild.id;

            // جلب المنتجات من قاعدة البيانات
            let products = db.get(`Products_${guildId}`) || [];
            const product = products.find(p => p.name === productName);

            // التحقق من وجود المنتج
            if (!product) {
                return interaction.reply({
                    content: `❌ المنتج **${productName}** غير موجود!`,
                    ephemeral: true,
                });
            }

            // التحقق من توفر الكمية
            if (product.stock.length < quantity) {
                return interaction.reply({
                    content: `❌ الكمية المطلوبة غير متوفرة! المتوفر حاليًا: **${product.stock.length}**.`,
                    ephemeral: true,
                });
            }

            // استخراج العناصر من الستوك
            const givenItems = product.stock.splice(0, quantity);
            db.set(`Products_${guildId}`, products); // تحديث قاعدة البيانات

            // إنشاء Embed لتأكيد الإعطاء
            const successEmbed = new EmbedBuilder()
                .setTitle('✅ تم إعطاء المنتجات بنجاح!')
                .setDescription(`تم إرسال المنتجات إلى ${targetUser}.`)
                .setTimestamp();

            await interaction.reply({ content: `${interaction.user}`, embeds: [successEmbed] });

            // إرسال المنتجات في خاص المستخدم
            const goodsEmbed = new EmbedBuilder()
                .setTitle('🛍️ منتجاتك')
                .setDescription('هذه هي المنتجات التي حصلت عليها:')
                .setTimestamp();

            givenItems.forEach(item => {
                goodsEmbed.addFields({ name: 'منتج:', value: `\`\`\`${item}\`\`\``, inline: false });
            });

            await targetUser.send({ embeds: [goodsEmbed] });

        } catch (error) {
            console.error(error);
            interaction.reply({
                content: '❌ حدث خطأ أثناء إرسال المنتجات!',
                ephemeral: true,
            });
        }
    },
};
