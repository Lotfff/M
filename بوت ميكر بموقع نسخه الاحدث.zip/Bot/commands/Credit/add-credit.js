const {
    SlashCommandBuilder,
    EmbedBuilder,
    ChatInputCommandInteraction,
    PermissionFlagsBits,
} = require("discord.js");
const { Database } = require("st.db");
const creditDB = new Database("./Bot/Json-Database/Settings/creditDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-credit')
        .setDescription('إضافة كريدت إلى مستخدم.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم الذي تريد إضافة الكريدت له.')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('كمية الكريدت المراد إضافتها.')
                .setRequired(true)
        ),
    type: "Credit",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction) {
        try {
            const user = interaction.options.getUser('user');
            const amount = interaction.options.getInteger('amount');

            let userCredits = creditDB.get(`credits_${user.id}_${interaction.guild.id}`) || 0;
            userCredits += amount;

            creditDB.set(`credits_${user.id}_${interaction.guild.id}`, userCredits);

            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('✅ تم إضافة الكريدت بنجاح!')
                .setDescription(`تمت إضافة **${amount}** كريدت إلى ${user}.\nرصيده الحالي: **${userCredits}**`)
                .setTimestamp();

            interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            interaction.reply({
                content: '❌ حدث خطأ أثناء تنفيذ الأمر.',
                ephemeral: true,
            });
        }
    },
};
