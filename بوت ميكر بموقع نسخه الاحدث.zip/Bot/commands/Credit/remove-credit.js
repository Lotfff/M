const {
    SlashCommandBuilder,
    EmbedBuilder,
    ChatInputCommandInteraction,
    PermissionFlagsBits,
} = require("discord.js");
const { Database } = require("st.db");
const creditDB = new Database("./Bot/Json-Database/Settings/creditDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove-credit')
        .setDescription('إزالة كريدت من مستخدم.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم الذي تريد إزالة الكريدت منه.')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('كمية الكريدت المراد إزالتها.')
                .setRequired(true)
        ),
    type: "Credit",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction) {
        try {
            const user = interaction.options.getUser('user');
            const amount = interaction.options.getInteger('amount');

            let userCredits = creditDB.get(`credits_${user.id}_${interaction.guild.id}`) || 0;

            if (amount > userCredits) {
                return interaction.reply({ content: '❌ لا يمكن إزالة كمية أكبر من رصيد المستخدم!', ephemeral: true });
            }

            userCredits -= amount;
            creditDB.set(`credits_${user.id}_${interaction.guild.id}`, userCredits);

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('✅ تم إزالة الكريدت بنجاح!')
                .setDescription(`تمت إزالة **${amount}** كريدت من ${user}.\nرصيده الحالي: **${userCredits}**`)
                .setTimestamp();

            interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            interaction.reply({
                content: '❌ حدث خطأ أثناء تنفيذ الأمر.',
                ephemeral: true,
            });
        }
    },
};
