const {
    SlashCommandBuilder,
    EmbedBuilder,
    ChatInputCommandInteraction,
    PermissionFlagsBits,
} = require("discord.js");
const { Database } = require("st.db");
const creditDB = new Database("./Bot/Json-Database/Settings/creditDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('transfer-credit')
        .setDescription('تحويل كريدت إلى مستخدم آخر.')
        .addUserOption(option =>
            option.setName('to-user')
                .setDescription('المستخدم الذي تريد تحويل الكريدت له.')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('كمية الكريدت التي تريد تحويلها.')
                .setRequired(true)
        ),
    type: "Credit",
    botP: [],
    

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction, language, reply, replyEmbeds) {
        try {
            const fromUser = interaction.user;
            const toUser = interaction.options.getUser('to-user');
            const amount = interaction.options.getInteger('amount');

            if (fromUser.id === toUser.id) {
                return interaction.reply({ content: '❌ لا يمكنك تحويل الكريدت لنفسك!', ephemeral: true });
            }

            let fromUserCredits = creditDB.get(`credits_${fromUser.id}_${interaction.guild.id}`) || 0;
            let toUserCredits = creditDB.get(`credits_${toUser.id}_${interaction.guild.id}`) || 0;

            if (amount > fromUserCredits) {
                return interaction.reply({ content: '❌ ليس لديك رصيد كافٍ!', ephemeral: true });
            }

            fromUserCredits -= amount;
            toUserCredits += amount;

            creditDB.set(`credits_${fromUser.id}_${interaction.guild.id}`, fromUserCredits);
            creditDB.set(`credits_${toUser.id}_${interaction.guild.id}`, toUserCredits);

            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('✅ تم التحويل بنجاح!')
                .setDescription(`تم تحويل **${amount}** كريدت من <@${fromUser.id}> إلى <@${toUser.id}>.`)
                .setTimestamp();

            interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            interaction.reply({
                embeds: [replyEmbeds.errorEmbed],
                ephemeral: true,
                allowedMentions: { repliedUser: false },
            });
        }
    },
};
