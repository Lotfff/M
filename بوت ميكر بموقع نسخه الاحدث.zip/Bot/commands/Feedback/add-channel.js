const {
    Client,
    Collection,
    EmbedBuilder,
    PermissionFlagsBits,
    SlashCommandBuilder,
    ChatInputCommandInteraction,
} = require("discord.js");
const { ChannelType } = require("discord-api-types/v9");
const { Database } = require("st.db");
const isImageUrl = require('is-image-url');

const db = new Database("./Bot/Json-Database/Settings/Feedback.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-feedback')
        .setDescription('Add a feedback channel with emoji and image.')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Pick the channel to monitor.')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
        )
        .addStringOption(option =>
            option.setName('emoji')
                .setDescription('Enter the emoji to react with.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('image-url')
                .setDescription('Provide the image URL to display.')
                .setRequired(true)
        ),
    type: "Feedback",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction, language, reply, replyEmbeds, name) {
        try {
            const channel = interaction.options.getChannel('channel');
            const emoji = interaction.options.getString('emoji');
            const imageUrl = interaction.options.getString('image-url');

            // التحقق من صحة الرابط
            if (!isImageUrl(imageUrl)) {
                return interaction.reply({
                    content: '❌ الرابط الذي أدخلته ليس رابط صورة صالح!',
                    ephemeral: true,
                });
            }

            // التحقق من إضافة القناة مسبقًا
            let channels = db.get(`Feedback_${interaction.guild.id}_${client.user.id}`) || [];
            if (channels.includes(channel.id)) {
                return interaction.reply({
                    content: reply.Feedback.Reply2.replace("[CHANNEL]", channel.name),
                    allowedMentions: { repliedUser: false },
                });
            }

            // حفظ الإعدادات في قاعدة البيانات
            db.push(`Feedback_${interaction.guild.id}_${client.user.id}`, channel.id);
            db.set(`FeedbackEmoji_${interaction.guild.id}`, emoji);
            db.set(`FeedbackImage_${interaction.guild.id}`, imageUrl);

            // تأكيد الإعداد
            interaction.reply({
                content: reply.Feedback.Reply1.replace("[CHANNEL]", channel.name),
                allowedMentions: { repliedUser: false },
            });

            // مراقبة الرسائل في القناة المحددة
            const filter = msg => msg.channel.id === channel.id && !msg.author.bot;
            const collector = channel.createMessageCollector({ filter });

            collector.on('collect', message => {
                // إرسال الصورة
                message.channel.send({ content: imageUrl });

                // إضافة الإيموجي على الرسالة
                message.react(emoji).catch(console.error);
            });

        } catch (error) {
            console.error(error);
            interaction.reply({
                embeds: [replyEmbeds.errorEmbed],
                ephemeral: true,
                allowedMentions: { repliedUser: false },
            });
        }
    },
};
