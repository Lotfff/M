const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    ChatInputCommandInteraction,
    EmbedBuilder,
    Events,
    ChannelType
} = require("discord.js");
const { Database } = require("st.db");
const db = new Database("./Bot/Json-Database/Settings/Suggestion.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-suggestion')
        .setDescription('Add a new suggestion channel with optional image.')
        .addChannelOption(channel =>
            channel.setName("channel")
                .setDescription("Pick the channel to add.")
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
        )
        .addStringOption(option =>
            option.setName("image")
                .setDescription("Provide an image URL (optional).")
                .setRequired(false)
        ),
    type: "Suggestion",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction, language, reply, replyEmbeds, name) {
        try {
            // الحصول على القناة من الإدخال
            const channel = interaction.options.getChannel("channel");

            // التحقق من وجود الصورة في الإدخال أو استرجاع الصورة المخزنة
            const imageUrl = interaction.options.getString("image") || db.get(`Image_${channel.id}`);

            if (!imageUrl) {
                return interaction.reply({
                    content: "⚠️ لم يتم العثور على صورة. يرجى توفير رابط صورة صالح!",
                    ephemeral: true
                });
            }

            // التحقق مما إذا كانت القناة مضافة مسبقًا
            let channels = db.get(`Suggestion_${interaction.guild.id}_${client.user.id}`) || [];
            if (channels.includes(channel.id)) {
                return interaction.reply({
                    content: reply.Suggestion.Reply2.replace("[CHANNEL]", channel),
                    allowedMentions: { repliedUser: false }
                });
            }

            // تخزين القناة والصورة في قاعدة البيانات
            db.push(`Suggestion_${interaction.guild.id}_${client.user.id}`, channel.id);
            db.set(`Image_${channel.id}`, imageUrl);

            interaction.reply({
                content: reply.Suggestion.Reply3.replace("[CHANNEL]", channel),
                allowedMentions: { repliedUser: false }
            });

            // الاستماع للرسائل في القناة المحددة
            client.on(Events.MessageCreate, async (msg) => {
                if (msg.channel.id !== channel.id || msg.author.bot) return; // تجاهل رسائل البوتات

                const storedImageUrl = db.get(`Image_${msg.channel.id}`);

                // إنشاء Embed يعرض الصورة
                const embed = new EmbedBuilder()
                    .setImage(storedImageUrl)
                    .setColor("#00FF00");

                // الرد بالصورة وإضافة الإيموجيين
                msg.reply({ embeds: [embed] });
                await msg.react("✅");
                await msg.react("❌");
            });

        } catch (error) {
            console.error(error);
            return interaction.reply({
                embeds: [replyEmbeds.errorEmbed],
                ephemeral: true,
                allowedMentions: { repliedUser: false }
            });
        }
    },
};
