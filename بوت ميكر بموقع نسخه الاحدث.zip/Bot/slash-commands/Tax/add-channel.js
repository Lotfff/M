const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    ChannelType,
    ChatInputCommandInteraction,
    Events
} = require("discord.js");
const { Database } = require("st.db");
const db = new Database("./Bot/Json-Database/Settings/Tax.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-tax')
        .setDescription('Add a new tax channel and enable tax calculation.')
        .addChannelOption(channel =>
            channel.setName("channel")
                .setDescription("Select the channel to monitor.")
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
        ),
    type: "Tax",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction, language, reply, replyEmbeds, name) {
        try {
            // الحصول على القناة المُختارة
            let channel = interaction.options.getChannel("channel");
            let channels = db.get("Tax_" + interaction.guild.id + "_" + client.user.id) || [];

            // التحقق مما إذا كانت القناة مضافة مسبقًا
            if (channels.includes(channel.id)) {
                return interaction.reply({
                    content: reply.Tax.Reply1.replace("[CHANNEL]", channel),
                    allowedMentions: { repliedUser: false }
                });
            }

            // إضافة القناة إلى قاعدة البيانات
            db.push("Tax_" + interaction.guild.id + "_" + client.user.id, channel.id).then(() => {
                interaction.reply({
                    content: reply.Tax.Reply2.replace("[CHANNEL]", channel),
                    allowedMentions: { repliedUser: false }
                });
            });

            // الاستماع للرسائل داخل القناة المضافة
            client.on(Events.MessageCreate, async (message) => {
                if (message.author.bot) return; // تجاهل رسائل البوت

                // التحقق من أن الرسالة في القناة المُفعّلة
                let activeChannels = db.get("Tax_" + message.guild.id + "_" + client.user.id) || [];
                if (!activeChannels.includes(message.channel.id)) return;

                let number = message.content;
                try {
                    // تحويل الصيغ مثل K و M إلى أرقام
                    if (number.endsWith("m")) number = number.replace(/m/gi, "") * 1000000;
                    else if (number.endsWith("k") || number.endsWith("K")) number = number.replace(/k/gi, "") * 1000;
                    else if (number.endsWith("M")) number = number.replace(/M/gi, "") * 1000000;
                    else if (number.endsWith("B") || number.endsWith("b")) number = number.replace(/b/gi, "") * 1000000000;
                    else if (number.endsWith("T") || number.endsWith("t")) number = number.replace(/t/gi, "") * 1000000000000;

                    let amount = parseInt(number);
                    if (isNaN(amount)) return; // تجاهل الرسالة إذا لم تكن رقمًا صالحًا

                    // حساب الضريبة وإرسال الرد
                    let tax = Math.floor(amount * (20 / 19) + 1);
                    message.reply({
                        content: `**> ${tax}**`,
                        allowedMentions: { repliedUser: false }
                    });
                } catch (error) {
                    console.log(error);
                }
            });

        } catch (error) {
            console.log(error);
            interaction.reply({
                embeds: [replyEmbeds.errorEmbed],
                ephemeral: true,
                allowedMentions: { repliedUser: false }
            });
        }
    },
};
