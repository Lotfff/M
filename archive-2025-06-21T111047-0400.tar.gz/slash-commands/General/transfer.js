const { SlashCommandBuilder } = require("@discordjs/builders");

module.exports = {

  data: new SlashCommandBuilder()

    .setName("transfer")

    .setDescription("تحويل الكوينز إلى مستخدم آخر")

    .addUserOption(u => u

      .setName('target')

      .setDescription(`المستخدم الذي تريد إرسال الكوينز إليه`)

      .setRequired(true))

    .addIntegerOption(option => option

      .setName('amount')

      .setDescription('كمية الكوينز التي تريد تحويلها')

      .setRequired(true))

  ,

  ownerOnly: false,

  async run(client, interaction) {

    try {

      // التأكد من وجود قواعد البيانات

      const balanceSchema = require('../../Schema/Balance');

      const blacklistSchema = require('../../Schema/Blacklist');

      

      if (!balanceSchema || !blacklistSchema) {

        return interaction.reply({

          content: `❌ خطأ في قاعدة البيانات 109، حاول مرة أخرى لاحقًا...`,

          ephemeral: true

        });

      }

      // جلب معلومات المستخدم

      const sender = interaction.user; // الشخص المرسل

      const target = interaction.options.getUser('target'); // الشخص المستقبل

      const amount = interaction.options.getInteger('amount'); // كمية الكوينز

      // لا يمكن تحويل الكوينز لنفسك

      if (target.id === sender.id) {

        return interaction.reply({ 

          content: `❌ لا يمكنك تحويل الكوينز لنفسك!`, 

          ephemeral: true 

        });

      }

      // جلب رصيد المرسل من قاعدة البيانات، إذا لم يوجد، يتم إنشاؤه

      let senderData = await balanceSchema.findOne({ userid: sender.id, guild: interaction.guild.id });

      if (!senderData) {

        senderData = new balanceSchema({ userid: sender.id, guild: interaction.guild.id, balance: 0 });

      }

      // جلب رصيد المستقبل من قاعدة البيانات، إذا لم يوجد، يتم إنشاؤه

      let targetData = await balanceSchema.findOne({ userid: target.id, guild: interaction.guild.id });

      if (!targetData) {

        targetData = new balanceSchema({ userid: target.id, guild: interaction.guild.id, balance: 0 });

      }

      let senderCoins = senderData.balance || 0;

      let targetCoins = targetData.balance || 0;

      // التأكد من أن المرسل لديه رصيد كافي

      if (senderCoins < amount) {

        return interaction.reply({

          content: `❌ لا تملك رصيد كافٍ لتحويل \`${amount}\` كوينز!`,

          ephemeral: true

        });

      }

      // تحديث الرصيد لكل من المرسل والمستقبل

      senderData.balance = senderCoins - amount;

      targetData.balance = targetCoins + amount;

      // حفظ البيانات في قاعدة البيانات

      await senderData.save();

      await targetData.save();

      // رسالة النجاح

      interaction.reply({

        content: `**:moneybag: | ${interaction.user.username}, has transferred \`${amount}\` to  <@${target.id}>**`

      });

    } catch (error) {

      console.error(error);

      await interaction.reply({

        content: `❌ حدث خطأ أثناء تنفيذ الأمر، حاول مرة أخرى لاحقًا.`,

        ephemeral: true

      });

    }

  },

};