const { SlashCommandBuilder } = require("@discordjs/builders");

const { EmbedBuilder } = require("discord.js");

module.exports = {

  data: new SlashCommandBuilder()

    .setName("topcoins")

    .setDescription("عرض أعلى 10 أشخاص لديهم أكبر عدد من الكوينز"),

  ownerOnly: false,

  async run(client, interaction) {

    try {

      const balanceSchema = require('../../Schema/Balance');

      // التأكد من وجود قاعدة البيانات

      if (!balanceSchema) {

        return interaction.reply({

          content: `❌ خطأ في قاعدة البيانات، حاول مرة أخرى لاحقًا.`,

          ephemeral: true

        });

      }

      // جلب جميع بيانات المستخدمين من قاعدة البيانات

      const allUsers = await balanceSchema.find({ guild: interaction.guild.id });

      if (allUsers.length === 0) {

        return interaction.reply({

          content: `❌ لا يوجد أي مستخدمين مسجلين.`,

          ephemeral: true

        });

      }

      // ترتيب المستخدمين حسب الرصيد (من الأعلى إلى الأقل)

      const topUsers = allUsers.sort((a, b) => b.balance - a.balance).slice(0, 10);

      // بناء رسالة Embed لعرض أفضل 10 مستخدمين

      const embed = new EmbedBuilder()

        .setTitle('🏆 أفضل 10 مستخدمين بالكوينز 🏆')

        .setColor('#FFD700')

        .setFooter({ text: `Leaderboard by ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() });

      // جلب أسماء المستخدمين من ديسكورد

      for (const [index, user] of topUsers.entries()) {

        const discordUser = await client.users.fetch(user.userid);  // جلب بيانات المستخدم من ديسكورد

        embed.addFields([{ name: `#${index + 1} ${discordUser.username}`, value: `رصيد: ${user.balance} كوينز` }]);

      }

      // إرسال الرسالة

      return interaction.reply({ embeds: [embed] });

    } catch (error) {

      console.error(error);

      return interaction.reply({

        content: `❌ حدث خطأ أثناء تنفيذ الأمر، حاول مرة أخرى لاحقًا.`,

        ephemeral: true

      });

    }

  },

};