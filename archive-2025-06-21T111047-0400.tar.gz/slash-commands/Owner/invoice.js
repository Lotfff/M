const {

    Client,

    Collection,

    Discord,

    createInvite,

    WebhookClient,

    PermissionsBitField,

    GatewayIntentBits,

    Partials,

    ApplicationCommandType,

    ApplicationCommandOptionType,

    Events,

    StringSelectMenuBuilder,

    ModalBuilder,

    TextInputBuilder,

    TextInputStyle,

    ContextMenuCommandBuilder,

    REST,

    Routes,

    GatewayCloseCodes,

    ActionRowBuilder,

    ButtonBuilder,

    ButtonStyle,

    EmbedBuilder,

    SlashCommandBuilder,

    PermissionFlagsBits

} = require("discord.js");

module.exports = {

    data: new SlashCommandBuilder()

        .setName("create-invoice")

        .setDescription("Create an invoice for a transaction")

        .addStringOption(option => option

            .setName("seller_id")

            .setDescription("ID of the seller")

            .setRequired(true))

        .addStringOption(option => option

            .setName("client_id")

            .setDescription("ID of the client")

            .setRequired(true))

        .addNumberOption(option => option

            .setName("amount")

            .setDescription("Transaction amount")

            .setRequired(true))

        .addStringOption(option => option

            .setName("transaction_type")

            .setDescription("Type of product or transaction")

            .setRequired(true))  // إضافة نوع المعاملة هنا

        .addStringOption(option => option

            .setName("image_url")

            .setDescription("URL of the image")

            .setRequired(true))

        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    ownerOnly: true,

    async run(client, interaction) {

        try {

            const sellerId = interaction.options.getString('seller_id');

            const clientId = interaction.options.getString('client_id');

            const amount = interaction.options.getNumber('amount');

            const transactionType = interaction.options.getString('transaction_type'); // الحصول على نوع المعاملة

            const imageUrl = interaction.options.getString('image_url');

            const invoiceChannel = client.channels.cache.get('1087441403124125696'); // استبدل CHANNEL_ID بمعرف الروم المستهدف

            // إنشاء Embed مع العنوان والبيانات

            const invoiceEmbed = new EmbedBuilder()

                .setTitle("تفاصيل الفاتورة")  // عنوان الإيمبد

                .setDescription(`**البائع:** <@${sellerId}>\n**العميل:** <@${clientId}>\n**نوع طلب:** ${transactionType}\n**المبلغ:** ${amount} `)

                .setColor("#00FF00"); // لون الإيمبد

            // إرسال الإيمبد مع البيانات

            await invoiceChannel.send({ embeds: [invoiceEmbed] });

            // إرسال الصورة كرابط خارج الإيمبد

            await invoiceChannel.send(imageUrl);  // سيتم عرض الصورة في رسالة منفصلة

            // تأكيد عملية الإرسال

            await interaction.reply({ content: "تم إرسال الفاتورة بنجاح!", ephemeral: true });

        } catch (error) {

            console.error("Error creating invoice:", error);

            await interaction.reply("حدث خطأ أثناء إنشاء الفاتورة.");

        }

    },

};