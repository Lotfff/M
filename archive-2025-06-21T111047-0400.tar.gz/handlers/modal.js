const fs = require('fs');
const path = require('path');

module.exports = (client) => {
    const modalsPath = path.join(__dirname, '../Bot/modals');

    if (!fs.existsSync(modalsPath)) {
        console.log('Modals directory not found at:', modalsPath);
        return;
    }

    fs.readdirSync(modalsPath).forEach((folder) => {
        const folderPath = path.join(modalsPath, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        for(file of commandFiles) {
            let commands = require(path.join(folderPath, file));
            if(commands.name) {
                client.modal.set(commands.name, commands);
            } else {
                continue;
            }
        }
    });
}