const {
    Client,
    SlashCommandBuilder,
    PermissionFlagsBits,
    ChatInputCommandInteraction
} = require("discord.js");
const { Database } = require("st.db");

const db = new Database("./Bot/Json-Database/Settings/shopDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-stock')
        .setDescription('إضافة عدة عناصر إلى ستوك منتج معين.')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('اسم المنتج.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('stock')
                .setDescription('العناصر المراد إضافتها (افصلها بفاصلة ,).')
                .setRequired(true)
        ),
    type: "Shop",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    support: false,
    ownerOnly: false,

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction, language, reply, replyEmbeds) {
        try {
            const productName = interaction.options.getString('name');
            const stockItemsString = interaction.options.getString('stock');
            const guildId = interaction.guild.id;

            // تقسيم العناصر باستخدام الفاصلة وتحويلها إلى مصفوفة
            const stockItems = stockItemsString.split(',').map(item => item.trim());

            // جلب قائمة المنتجات من قاعدة البيانات
            let products = db.get(`Products_${guildId}`) || [];

            // البحث عن المنتج المطلوب
            let product = products.find(p => p.name === productName);

            // التحقق من وجود المنتج
            if (!product) {
                return interaction.reply({
                    content: `❌ المنتج **${productName}** غير موجود!`,
                    ephemeral: true,
                });
            }

            // التحقق من وجود قائمة ستوك، وإنشاء واحدة جديدة إذا لم تكن موجودة
            if (!product.stock) {
                product.stock = [];
                console.log(`⚠️ تم إنشاء قائمة ستوك جديدة للمنتج: ${productName}`);
            }

            // إضافة العناصر إلى ستوك المنتج
            product.stock.push(...stockItems);

            // تحديث قاعدة البيانات
            db.set(`Products_${guildId}`, products);

            // تأكيد الإضافة
            interaction.reply({
                content: `✅ تم إضافة العناصر [${stockItems.join(', ')}] إلى المنتج **${productName}**.`,
                allowedMentions: { repliedUser: false },
            });

        } catch (error) {
            console.error(error);
            interaction.reply({
                content: '❌ حدث خطأ أثناء إضافة الستوك!',
                ephemeral: true,
            });
        }
    },
};
