const { 
    SlashCommandBuilder, 
    PermissionFlagsBits, 
    ChatInputCommandInteraction, 
    EmbedBuilder 
} = require("discord.js");
const { Database } = require("st.db");

const db = new Database("./Bot/Json-Database/Settings/shopDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('show-products')
        .setDescription('عرض جميع المنتجات مع عدد الستوك المتاح لكل منتج.'),
    type: "Shop",
    
    

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    
    async run(client, interaction) {
        try {
            const guildId = interaction.guild.id;

            // جلب قائمة المنتجات من قاعدة البيانات
            let products = db.get(`Products_${guildId}`) || [];
if (!Array.isArray(products)) {
      products = [];
    }
            // التحقق من وجود منتجات
            if (products.length === 0) {
                return interaction.reply({
                    content: '❌ لا توجد منتجات متاحة حاليًا!',
                    ephemeral: true,
                });
            }

            // إنشاء Embed لعرض المنتجات
            const embed = new EmbedBuilder()
                .setTitle('🛒 قائمة المنتجات')
                .setColor('Blue')
                .setTimestamp();

            // إضافة كل منتج كحقل داخل الـEmbed
            products.forEach(product => {
                embed.addFields({
                    name: `📦 ${product.name}`, // اسم المنتج كعنوان
                    value: `💵 **السعر:** ${product.price}\n📦 **عدد الستوك:** ${product.stock.length}`,
                    inline: false, // عرض كل منتج في سطر جديد
                });
            });

            // إرسال الـEmbed كرد
            interaction.reply({
                embeds: [embed],
                allowedMentions: { repliedUser: false },
            });

        } catch (error) {
            console.error(error);
            interaction.reply({
                content: '❌ حدث خطأ أثناء عرض المنتجات!',
                ephemeral: true,
            });
        }
    },
};

