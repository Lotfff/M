const {
    SlashCommandBuilder,
    EmbedBuilder,
    ChatInputCommandInteraction,
    PermissionFlagsBits,
} = require("discord.js");
const { Database } = require("st.db");
const creditDB = new Database("./Bot/Json-Database/Settings/creditDB.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('balance')
        .setDescription('عرض رصيد الكريدت الخاص بك أو لمستخدم آخر.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('عرض رصيد مستخدم آخر (اختياري).')
        ),
    type: "Credit",
    botP: [],
    

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async run(client, interaction, language, reply, replyEmbeds) {
        try {
            const user = interaction.options.getUser('user') || interaction.user;
            const credits = creditDB.get(`credits_${user.id}_${interaction.guild.id}`) || 0;

            const embed = new EmbedBuilder()
                .setColor('#0000FF')
                .setTitle(`رصيد ${user.username}`)
                .setDescription(`لديك **${credits}** كريدت.`)
                .setTimestamp();

            interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            interaction.reply({
                embeds: [replyEmbeds.errorEmbed],
                ephemeral: true,
                allowedMentions: { repliedUser: false },
            });
        }
    },
};
